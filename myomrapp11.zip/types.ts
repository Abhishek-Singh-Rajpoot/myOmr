
export enum AppView {
  AUTH = 'AUTH',
  DASHBOARD = 'DASHBOARD',
  SETUP = 'SETUP',
  SOLVING = 'SOLVING',
  RESULTS = 'RESULTS',
  HISTORY = 'HISTORY',
  AI_ASSISTANT = 'AI_ASSISTANT',
  ABOUT = 'ABOUT',
  NEWS = 'NEWS'
}

export interface UserProfile {
  email: string;
  name: string;
  photo?: string;
}

export interface ExamConfig {
  totalQuestions: number;
  optionsPerQuestion: number;
  marksPerCorrect: number;
  negativeMarking: number;
  instantFeedback: boolean;
}

export interface AnswerKey {
  [questionNumber: number]: string;
}

export interface UserResponses {
  [questionNumber: number]: string;
}

export interface ExamResult {
  score: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  marksDeducted: number;
  maxScore: number;
  timestamp: number;
}

export interface QuizQuestion {
  id: number;
  text: string;
  options: string[];
  correctAnswer: string; // 'A', 'B', 'C', 'D'
}

export interface SavedExam {
  id: string;
  name: string;
  date: string;
  config: ExamConfig;
  answerKey: AnswerKey;
  questionsContent?: string;
  quizData?: QuizQuestion[];
  result?: ExamResult;
  sourceType: 'IMAGE' | 'TEXT' | 'MANUAL';
  status: 'COMPLETED' | 'IN_PROGRESS'; // Added to track exam state
  savedResponses?: UserResponses; // Added to store partial progress
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
