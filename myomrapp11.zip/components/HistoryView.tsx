
import React, { useState } from 'react';
import { SavedExam } from '../types';

interface HistoryViewProps {
  exams: SavedExam[];
  onLoad: (exam: SavedExam) => void;
  onEdit: (exam: SavedExam) => void;
  onDelete: (id: string) => void;
  onAddClick: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ exams, onLoad, onEdit, onDelete, onAddClick }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredExams = exams.filter(exam => 
    exam.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black text-black tracking-tight">Archives</h2>
          <p className="text-black/60 font-medium">Revisit your past attempts and analysis.</p>
        </div>
        <button 
          onClick={onAddClick}
          className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition-all shadow-xl shadow-blue-100"
        >
          <i className="fa-solid fa-plus mr-2"></i> New Session
        </button>
      </div>

      <div className="relative">
        <i className="fa-solid fa-magnifying-glass absolute left-5 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input 
          type="text" 
          placeholder="Search archives by name..."
          className="w-full pl-14 pr-6 py-5 bg-white border border-slate-100 rounded-[2rem] focus:ring-4 focus:ring-blue-50 outline-none transition-all shadow-sm font-medium text-black"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredExams.length === 0 ? (
        <div className="text-center py-24 bg-white rounded-[3rem] shadow-sm border border-slate-100">
          <div className="w-24 h-24 bg-slate-50 text-slate-200 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fa-solid fa-box-open text-4xl"></i>
          </div>
          <h3 className="text-2xl font-black text-black">Your archive is empty</h3>
          <p className="text-black/50 font-medium mt-2 max-w-sm mx-auto">Start a new practice session or scan an answer key to build your history.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredExams.map((exam) => (
            <div key={exam.id} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 hover:border-blue-400 transition-all group relative hover:shadow-xl hover:shadow-blue-50/50 flex flex-col h-full">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-3">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-md ${exam.status === 'IN_PROGRESS' ? 'bg-orange-500 text-white' : 'bg-slate-900 text-white group-hover:bg-blue-600'}`}>
                    {exam.status === 'IN_PROGRESS' ? (
                       <i className="fa-solid fa-hourglass-half text-xl animate-pulse"></i>
                    ) : (
                       <i className="fa-solid fa-file-invoice text-xl"></i>
                    )}
                  </div>
                  {exam.questionsContent && (
                    <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center border border-blue-100" title="Question paper attached">
                      <i className="fa-solid fa-file-circle-check text-sm"></i>
                    </div>
                  )}
                </div>
                <button 
                  onClick={() => onDelete(exam.id)}
                  className="text-slate-300 hover:text-red-500 transition-colors p-2"
                >
                  <i className="fa-solid fa-trash-can text-sm"></i>
                </button>
              </div>

              <div className="space-y-1 mb-6 flex-grow">
                <h4 className="font-black text-black text-xl line-clamp-2 leading-tight h-14">{exam.name}</h4>
                <div className="flex items-center gap-4 text-[10px] font-black text-black/40 uppercase tracking-widest pt-2 border-t border-slate-50">
                   <div className="flex items-center gap-1">
                     <i className="fa-regular fa-calendar-check"></i>
                     {new Date(exam.date).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}
                   </div>
                   <div className="flex items-center gap-1">
                     <i className="fa-solid fa-list-ol"></i>
                     {exam.config.totalQuestions} Qs
                   </div>
                </div>
              </div>

              {exam.status === 'IN_PROGRESS' ? (
                <div className="bg-orange-50 border border-orange-100 p-4 rounded-2xl mb-8">
                  <p className="text-orange-600 font-black text-xs uppercase tracking-widest flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></span>
                    Attempt In Progress
                  </p>
                  <p className="text-orange-800/60 text-[10px] font-bold mt-1">
                     {Object.keys(exam.savedResponses || {}).length} questions solved so far.
                  </p>
                </div>
              ) : (
                <div className="bg-slate-50 p-4 rounded-2xl mb-8 flex items-center justify-between">
                   <div>
                     <p className="text-[9px] font-black text-black/40 uppercase tracking-wider">Score</p>
                     <p className="text-xl font-black text-blue-600">{exam.result?.score.toFixed(1) || 0} <span className="text-xs text-black/40 font-bold">/ {exam.result?.maxScore || 0}</span></p>
                   </div>
                   <div className="text-right">
                     <p className="text-[9px] font-black text-black/40 uppercase tracking-wider">Accuracy</p>
                     <p className="text-xl font-black text-black">{((exam.result?.correctCount || 0) / ((exam.result?.correctCount || 0) + (exam.result?.incorrectCount || 0) || 1) * 100).toFixed(0)}%</p>
                   </div>
                </div>
              )}

              <div className="flex gap-3">
                <button 
                  onClick={() => onEdit(exam)}
                  className="flex-1 py-4 bg-slate-100 text-black hover:bg-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest transition-all"
                >
                  <i className="fa-solid fa-pen-to-square mr-2"></i> Edit
                </button>
                <button 
                  onClick={() => onLoad(exam)}
                  className={`flex-[2] py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all active:scale-95 ${exam.status === 'IN_PROGRESS' ? 'bg-orange-500 text-white hover:bg-orange-600 shadow-lg shadow-orange-100' : 'bg-slate-100 text-black hover:bg-blue-600 hover:text-white'}`}
                >
                  {exam.status === 'IN_PROGRESS' ? (
                    <>Resume <i className="fa-solid fa-arrow-right ml-2"></i></>
                  ) : (
                    'Review'
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryView;
