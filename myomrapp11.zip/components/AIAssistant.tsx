
import React, { useState, useRef, useEffect } from 'react';
import { sendChatMessage } from '../services/geminiService';
import { ChatMessage, ExamConfig, ExamResult } from '../types';

interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  timestamp: number;
}

interface AIAssistantProps {
  currentConfig?: ExamConfig;
  currentResult?: ExamResult;
  userEmail?: string;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ currentConfig, currentResult, userEmail }) => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const storageKey = `omniomr_sessions_${userEmail || 'guest'}`;

  // Load sessions on mount
  useEffect(() => {
    const savedSessions = localStorage.getItem(storageKey);
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        setSessions(parsed);
        if (parsed.length > 0) {
          setActiveSessionId(parsed[0].id);
        } else {
          startNewChat();
        }
      } catch (e) {
        console.error("Failed to load sessions", e);
        startNewChat();
      }
    } else {
      startNewChat();
    }
  }, [userEmail]);

  // Save sessions on update
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem(storageKey, JSON.stringify(sessions));
    }
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sessions]);

  const startNewChat = () => {
    const newId = Date.now().toString();
    const newSession: ChatSession = {
      id: newId,
      title: 'New Chat',
      messages: [
        { role: 'model', text: 'Namaste! I am your OmniAI Study Assistant. I can help you with UPSC, SSC, or any competitive exam queries. \n\nHow can I help you today?', timestamp: Date.now() }
      ],
      timestamp: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newId);
    setShowHistory(false);
  };

  const currentSession = sessions.find(s => s.id === activeSessionId) || null;

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Delete this entire chat?")) {
      const filtered = sessions.filter(s => s.id !== id);
      setSessions(filtered);
      if (activeSessionId === id) {
        setActiveSessionId(filtered.length > 0 ? filtered[0].id : null);
        if (filtered.length === 0) startNewChat();
      }
    }
  };

  const deleteMessage = (msgTimestamp: number) => {
    if (!confirm("Remove this message?")) return;
    setSessions(prev => prev.map(s => {
      if (s.id === activeSessionId) {
        return {
          ...s,
          messages: s.messages.filter(m => m.timestamp !== msgTimestamp)
        };
      }
      return s;
    }));
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping || !activeSessionId) return;

    const userMsg = input.trim();
    setInput('');
    const userMessage: ChatMessage = { role: 'user', text: userMsg, timestamp: Date.now() };

    setSessions(prev => prev.map(s => {
      if (s.id === activeSessionId) {
        const isFirstMsg = s.messages.length <= 1;
        return {
          ...s,
          title: isFirstMsg ? (userMsg.length > 30 ? userMsg.substring(0, 30) + '...' : userMsg) : s.title,
          messages: [...s.messages, userMessage]
        };
      }
      return s;
    }));

    setIsTyping(true);

    try {
      const contextString = currentResult 
        ? `The user just finished an exam. Score: ${currentResult.score}/${currentResult.maxScore}. Correct: ${currentResult.correctCount}, Incorrect: ${currentResult.incorrectCount}.`
        : currentConfig 
          ? `The user is currently preparing for an exam with ${currentConfig.totalQuestions} questions.`
          : '';

      const aiText = await sendChatMessage(
        [...(currentSession?.messages || []), userMessage],
        contextString
      );

      const aiMessage: ChatMessage = { role: 'model', text: aiText, timestamp: Date.now() };

      setSessions(prev => prev.map(s => {
        if (s.id === activeSessionId) {
          return { ...s, messages: [...s.messages, aiMessage] };
        }
        return s;
      }));
    } catch (error: any) {
      console.error("AI Error:", error);
      const errMsg: ChatMessage = { role: 'model', text: "Service temporarily unavailable. Please try again.", timestamp: Date.now() };
      setSessions(prev => prev.map(s => {
        if (s.id === activeSessionId) {
          return { ...s, messages: [...s.messages, errMsg] };
        }
        return s;
      }));
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto h-[80vh] flex bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden relative">
      <div className={`
        absolute inset-y-0 left-0 z-50 w-72 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out border-r border-white/10
        ${showHistory ? 'translate-x-0' : '-translate-x-full'} lg:relative lg:translate-x-0
      `}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-black text-xs uppercase tracking-widest text-blue-400">Old Chats</h3>
            <button onClick={() => setShowHistory(false)} className="lg:hidden text-white/50 hover:text-white">
              <i className="fa-solid fa-xmark"></i>
            </button>
          </div>
          
          <button 
            onClick={startNewChat}
            className="w-full flex items-center gap-3 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-xl font-bold text-sm transition-all mb-6 shadow-lg shadow-blue-900/20"
          >
            <i className="fa-solid fa-plus text-xs"></i> New Chat
          </button>

          <div className="flex-grow overflow-y-auto space-y-2 scrollbar-hide">
            {sessions.map(s => (
              <div 
                key={s.id}
                onClick={() => {
                  setActiveSessionId(s.id);
                  setShowHistory(false);
                }}
                className={`
                  group p-3 rounded-xl cursor-pointer transition-all flex items-center justify-between
                  ${activeSessionId === s.id ? 'bg-white/10 text-white' : 'text-white/50 hover:bg-white/5 hover:text-white'}
                `}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <i className={`fa-solid ${activeSessionId === s.id ? 'fa-message' : 'fa-clock-rotate-left'} text-xs opacity-50`}></i>
                  <span className="text-xs font-bold truncate">{s.title}</span>
                </div>
                <button 
                  onClick={(e) => deleteSession(s.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-all"
                >
                  <i className="fa-solid fa-trash-can text-[10px]"></i>
                </button>
              </div>
            ))}
          </div>

          <div className="pt-6 border-t border-white/10 mt-auto">
            <div className="flex items-center gap-3 text-white/30 text-[10px] font-black uppercase tracking-tighter">
              <i className="fa-solid fa-shield-halved"></i>
              E2E Encrypted History
            </div>
          </div>
        </div>
      </div>

      <div className="flex-grow flex flex-col min-w-0">
        <div className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 p-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className="lg:hidden w-10 h-10 flex items-center justify-center text-slate-400 hover:text-black dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-all"
            >
              <i className="fa-solid fa-bars"></i>
            </button>
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center border-2 border-blue-400 shadow-lg text-white">
              <i className="fa-solid fa-bolt text-sm"></i>
            </div>
            <div>
              <h3 className="font-black text-sm">OmniAI Tutor</h3>
              <p className="text-[9px] text-blue-600 dark:text-blue-400 uppercase font-black tracking-widest">
                {isTyping ? 'Thinking...' : 'Hindi • English • Active'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
             <button 
                onClick={() => setShowHistory(true)}
                className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
             >
                <i className="fa-solid fa-clock-rotate-left"></i> Old Chats
             </button>
          </div>
        </div>

        <div className="flex-grow overflow-y-auto p-4 sm:p-8 space-y-6 bg-slate-50/30 dark:bg-slate-950/30">
          {currentSession?.messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn group relative`}>
              <div className={`
                max-w-[85%] p-5 rounded-3xl text-sm leading-relaxed shadow-sm relative
                ${msg.role === 'user' 
                  ? 'bg-slate-900 dark:bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-white dark:bg-slate-800 text-black dark:text-white rounded-tl-none border border-slate-100 dark:border-slate-700'}
              `}>
                {msg.text.split('\n').map((line, i) => (
                  <p key={i} className={i > 0 ? 'mt-2' : ''}>{line}</p>
                ))}
                
                {/* Delete Individual Message Button */}
                <button 
                  onClick={() => deleteMessage(msg.timestamp)}
                  className={`
                    absolute top-[-8px] ${msg.role === 'user' ? 'left-[-8px]' : 'right-[-8px]'}
                    w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-[8px] hover:scale-110 shadow-lg
                  `}
                  title="Remove message"
                >
                  <i className="fa-solid fa-x"></i>
                </button>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 p-5 rounded-3xl rounded-tl-none flex gap-1.5 shadow-sm">
                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>

        <div className="p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
          <div className="flex gap-2 bg-slate-100 dark:bg-slate-950 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-inner group focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-50 dark:focus-within:ring-blue-900/20 transition-all">
            <input
              type="text"
              className="flex-grow px-4 py-2 outline-none bg-transparent text-sm font-medium"
              placeholder="Ask your study doubt here..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="w-12 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center hover:bg-blue-700 transition-all disabled:opacity-30 shadow-lg shadow-blue-200 dark:shadow-none"
            >
              <i className="fa-solid fa-paper-plane text-xs"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
