
import React, { useState, useEffect } from 'react';

interface AuthScreenProps {
  onLogin: (name: string, email: string) => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'EMAIL' | 'OTP'>('EMAIL');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showNotification, setShowNotification] = useState(false);

  const handleSendOtp = () => {
    if (!email || !email.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setIsLoading(true);
    
    // Simulate API call to send OTP
    setTimeout(() => {
      const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOtp(newOtp);
      setStep('OTP');
      setIsLoading(false);
      setShowNotification(true);
      // Automatically hide notification after 10 seconds
      setTimeout(() => setShowNotification(false), 10000);
    }, 1500);
  };

  const handleVerify = () => {
    if (otp === generatedOtp) {
      setError('');
      setIsLoading(true);
      setTimeout(() => {
        const namePrefix = email.split('@')[0];
        const displayName = namePrefix.charAt(0).toUpperCase() + namePrefix.slice(1);
        onLogin(displayName, email);
        setIsLoading(false);
      }, 1000);
    } else {
      setError('Invalid OTP. Please check the code and try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 font-['Inter'] relative overflow-hidden">
      {/* Background blobs for aesthetics */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-100 rounded-full blur-[120px] opacity-50"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-100 rounded-full blur-[120px] opacity-50"></div>

      {/* Simulated Email Notification Toast */}
      {showNotification && (
        <div className="fixed top-6 right-6 z-[100] max-w-sm w-full animate-slideInRight">
          <div className="bg-slate-900 text-white p-5 rounded-3xl shadow-2xl border border-white/10 flex items-start gap-4">
            <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center shrink-0">
              <i className="fa-solid fa-paper-plane text-sm"></i>
            </div>
            <div className="space-y-1">
              <p className="font-black text-xs uppercase tracking-widest text-blue-400">Email Received</p>
              <p className="text-sm font-medium text-white/90">Your OmniOMR Verification Code is:</p>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black tracking-widest text-white">{generatedOtp}</span>
                <button onClick={() => { navigator.clipboard.writeText(generatedOtp); }} className="text-[10px] bg-white/10 px-2 py-1 rounded hover:bg-white/20">COPY</button>
              </div>
              <p className="text-[10px] text-white/40 pt-2 border-t border-white/5 mt-2 italic">
                Note: In production, this would arrive in your inbox at {email}
              </p>
            </div>
            <button onClick={() => setShowNotification(false)} className="text-white/20 hover:text-white transition-colors">
              <i className="fa-solid fa-xmark"></i>
            </button>
          </div>
        </div>
      )}

      <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl border border-slate-100 p-10 text-center space-y-8 animate-fadeIn relative z-10">
        <div className="space-y-4">
          <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center text-white mx-auto shadow-xl shadow-blue-100 rotate-3 transition-transform hover:rotate-0">
            <i className="fa-solid fa-square-check text-4xl"></i>
          </div>
          <h1 className="text-4xl font-black text-black tracking-tight">Omni<span className="text-blue-600">OMR</span></h1>
          <p className="text-black/70 font-medium">Verify your account to access your data</p>
        </div>

        <div className="space-y-6">
          {step === 'EMAIL' ? (
            <div className="space-y-4">
              <div className="text-left space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
                <div className="relative">
                  <i className="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
                  <input 
                    type="email" 
                    placeholder="name@example.com" 
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-transparent rounded-2xl focus:border-blue-400 focus:bg-white outline-none transition-all font-medium text-black"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
              <button 
                onClick={handleSendOtp}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-3 bg-blue-600 text-white py-5 px-6 rounded-2xl hover:bg-blue-700 transition-all font-bold shadow-lg shadow-blue-100 disabled:opacity-50 active:scale-95"
              >
                {isLoading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <i className="fa-solid fa-paper-plane text-xs"></i>}
                Send Verification Code
              </button>
            </div>
          ) : (
            <div className="space-y-6 animate-fadeIn">
              <div className="text-left space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">6-Digit OTP</label>
                <div className="relative">
                  <i className="fa-solid fa-shield-halved absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
                  <input 
                    type="text" 
                    maxLength={6}
                    placeholder="000000" 
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-transparent rounded-2xl focus:border-blue-400 focus:bg-white outline-none transition-all font-black text-2xl tracking-[0.5em] text-center text-black"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  />
                </div>
                <div className="flex justify-between items-center px-1">
                  <p className="text-[10px] text-black/40 font-bold">Code sent to {email}</p>
                  {!showNotification && (
                    <button onClick={() => setShowNotification(true)} className="text-[10px] text-blue-600 font-black uppercase tracking-wider hover:underline">
                      Show Code
                    </button>
                  )}
                </div>
              </div>
              <button 
                onClick={handleVerify}
                disabled={isLoading || otp.length !== 6}
                className="w-full flex items-center justify-center gap-3 bg-green-600 text-white py-5 px-6 rounded-2xl hover:bg-green-700 transition-all font-bold shadow-lg shadow-green-100 disabled:opacity-50 active:scale-95"
              >
                {isLoading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <i className="fa-solid fa-check-double text-xs"></i>}
                Verify & Continue
              </button>
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => setStep('EMAIL')}
                  className="text-xs font-bold text-slate-400 hover:text-blue-600 transition-colors"
                >
                  Change Email Address
                </button>
                <button 
                  onClick={handleSendOtp}
                  className="text-xs font-black text-blue-600 hover:underline uppercase tracking-widest"
                >
                  Resend OTP
                </button>
              </div>
            </div>
          )}

          {error && <p className="text-red-500 text-xs font-bold animate-shake bg-red-50 py-2 rounded-lg">{error}</p>}
          
          <div className="flex items-center gap-4 py-2">
            <div className="h-px bg-slate-100 flex-grow"></div>
            <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Secured by OmniSafe</span>
            <div className="h-px bg-slate-100 flex-grow"></div>
          </div>
          
          <p className="text-[11px] text-black/50 px-4 leading-relaxed">
            By logging in, your exam data, AI chats, and history will be securely synced to your email. Data is stored separately for each account.
          </p>
        </div>
      </div>
      <style>{`
        @keyframes slideInRight {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        .animate-slideInRight {
          animation: slideInRight 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.2s ease-in-out 0s 2;
        }
      `}</style>
    </div>
  );
};

export default AuthScreen;
