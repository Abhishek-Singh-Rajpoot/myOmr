
import React, { useState, useEffect } from 'react';
import { fetchNewsAI } from '../services/geminiService';

interface NewsItem {
  title: string;
  summary: string;
  url: string;
  date: string;
  source?: string;
  isAI?: boolean;
}

const NewsView: React.FC = () => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [category, setCategory] = useState<'INDIA' | 'WORLD'>('INDIA');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sourceType, setSourceType] = useState<'API' | 'AI SEARCH' | null>(null);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // Gemini logic to refine news content for exam preparations
  const translateAndSummarize = async (rawData: any[], isAISearch = false) => {
    try {
      const context = JSON.stringify(rawData.slice(0, 8));
      
      const prompt = `
        You are a Hindi News Editor. 
        Raw data: ${context}
        
        Tasks:
        1. Translate titles to professional Hindi for exam aspirants.
        2. Create a 2-sentence summary in Hindi for each.
        3. Maintain original URLs.
        
        Return a JSON array of objects with keys: "title", "summary", "url", "date", "source".
      `;

      // Call backend wrapper
      const parsed = await fetchNewsAI(prompt, true);
      return parsed.map((item: any) => ({ ...item, isAI: isAISearch }));
    } catch (err: any) {
      console.error("AI Processing failed:", err);
      // Fallback: return raw data if translation fails
      return rawData.map(item => ({
        title: item.title || item.name || "News Update",
        summary: item.description || item.summary || "Description unavailable.",
        url: item.url || item.link || "#",
        date: item.publishedAt || item.date || new Date().toLocaleDateString(),
        source: item.source?.name || "News Desk",
        isAI: isAISearch
      }));
    }
  };

  // Fallback to Google Search grounding if external API fails
  const fetchViaAISearch = async (cat: 'INDIA' | 'WORLD') => {
    setSourceType('AI SEARCH');
    const region = cat === 'INDIA' ? 'India' : 'the World';
    
    const prompt = `Get the latest 8 current affairs news stories from ${region} from the last 24 hours. 
    Format as JSON array with: title (Hindi), summary (Hindi), url (Source link), date, source (Channel name).`;

    try {
      const data = await fetchNewsAI(prompt, false);
      return data.map((item: any) => ({ ...item, isAI: true }));
    } catch (err: any) {
      if (err.message?.includes('429') || err.message?.includes('quota')) {
        throw new Error("QUOTA_EXHAUSTED");
      }
      throw err;
    }
  };

  const fetchNews = async () => {
    setIsLoading(true);
    setError(null);
    setSourceType(null);

    try {
      const endpoint = category === 'INDIA' 
        ? 'https://news.knowivate.com/api/local' 
        : 'https://news.knowivate.com/api/latest';
      
      const response = await fetch(endpoint, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        mode: 'cors'
      });

      if (!response.ok) throw new Error("API_ERROR");
      
      const data = await response.json();
      const newsArray = Array.isArray(data) ? data : (data.articles || data.news || data.results || []);
      
      if (newsArray.length === 0) throw new Error("EMPTY_DATA");

      setSourceType('API');
      const formattedNews = await translateAndSummarize(newsArray, false);
      setNews(formattedNews);

    } catch (err: any) {
      console.warn("Direct API fetch failed or Translation failed.", err);
      
      // Try fallback search
      try {
        const aiNews = await fetchViaAISearch(category);
        setNews(aiNews);
      } catch (fallbackErr: any) {
        console.error("Critical Failure:", fallbackErr);
        
        if (fallbackErr.message === "QUOTA_EXHAUSTED" || fallbackErr.message?.includes('429')) {
          setError("API कोटा समाप्त हो गया है। (Daily AI usage limit reached.)");
        } else if (fallbackErr.message?.includes("API_KEY_MISSING") || fallbackErr.message?.includes("misconfiguration")) {
           setError("Server Configuration Error: API Key missing in backend.");
        } else {
          setError("सभी स्रोत विफल रहे। कृपया थोड़ी देर बाद प्रयास करें। (Service Unavailable)");
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [category]);

  const handleShareNews = async () => {
    if (news.length === 0) return;

    const shareText = `📚 *OmniOMR - Daily Current Affairs (${category})*\n` + 
      `🗓️ Date: ${new Date().toLocaleDateString()}\n\n` +
      news.slice(0, 4).map((n, i) => `${i+1}. *${n.title}*\n   ${n.summary}`).join('\n\n') + 
      ` \n\nCheck full news and solve OMR sheets on OmniOMR App!`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `OmniOMR Current Affairs - ${category}`,
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error('Error sharing:', err);
        }
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareText);
        setShareFeedback("Summary copied to clipboard! Share it on WhatsApp/Telegram.");
        setTimeout(() => setShareFeedback(null), 3000);
      } catch (err) {
        alert("Clipboard access failed. Please select text manually.");
      }
    }
  };

  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn relative">
      {/* Toast Notification for Clipboard Feedback */}
      {shareFeedback && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] bg-slate-900 text-white px-6 py-4 rounded-[2rem] shadow-2xl font-black text-xs uppercase tracking-widest no-print border border-white/10 flex items-center gap-3">
          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
            <i className="fa-solid fa-check text-[10px]"></i>
          </div>
          {shareFeedback}
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 no-print">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
             <h2 className="text-4xl font-black tracking-tight text-black dark:text-white flex items-center gap-3">
              <i className="fa-solid fa-newspaper text-orange-600"></i>
              Current Affairs
            </h2>
            {sourceType && (
              <span className={`text-[9px] font-black px-2 py-1 rounded-md tracking-widest uppercase ${sourceType === 'API' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'}`}>
                {sourceType}
              </span>
            )}
          </div>
          <p className="text-black/50 dark:text-white/50 font-medium">समसामयिक घटनाक्रम - Stay updated, Study focused.</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchNews}
            disabled={isLoading}
            className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-all no-print"
            title="Refresh News"
          >
            <i className={`fa-solid fa-arrows-rotate ${isLoading ? 'fa-spin' : ''}`}></i>
          </button>
          
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl no-print">
            <button 
              onClick={() => setCategory('INDIA')}
              className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${category === 'INDIA' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-400'}`}
            >
              India
            </button>
            <button 
              onClick={() => setCategory('WORLD')}
              className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${category === 'WORLD' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-400'}`}
            >
              World
            </button>
          </div>

          <button 
            onClick={handleShareNews}
            className="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-lg shadow-orange-100 dark:shadow-none no-print"
          >
            <i className="fa-solid fa-share-nodes mr-2"></i> Share
          </button>
          
          <button 
            onClick={handleExportPDF}
            className="px-4 py-2 bg-slate-900 dark:bg-slate-700 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-black transition-all no-print"
          >
            <i className="fa-solid fa-file-pdf mr-2"></i> PDF
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-32 space-y-4">
          <div className="w-16 h-16 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin"></div>
          <p className="text-black/50 dark:text-white/50 font-black text-xs uppercase tracking-[0.3em] animate-pulse">Fetching latest updates...</p>
        </div>
      ) : error ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-[3rem] text-center border border-red-100 dark:border-red-900/30 shadow-xl max-w-2xl mx-auto">
          <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fa-solid fa-triangle-exclamation text-4xl text-red-500"></i>
          </div>
          <h3 className="text-xl font-black text-black dark:text-white mb-2">Service Unavailable</h3>
          <p className="text-slate-600 dark:text-slate-400 font-medium mb-8 leading-relaxed">
            {error}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={fetchNews} className="px-8 py-3 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-700 transition-all">
              Try Again
            </button>
            <button onClick={() => window.location.reload()} className="px-8 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all">
              Reload App
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {news.map((item, idx) => (
            <div key={idx} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800 hover:border-orange-200 transition-all group flex flex-col h-full break-inside-avoid">
              <div className="flex justify-between items-start mb-4">
                <span className="text-[10px] font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest bg-orange-50 dark:bg-orange-900/20 px-3 py-1 rounded-full">
                  {item.source || 'Current Affairs'}
                </span>
                <span className="text-[10px] font-bold text-black/30 dark:text-white/30">
                  {item.date}
                </span>
              </div>
              <h3 className="text-xl font-black text-black dark:text-white mb-4 group-hover:text-orange-600 transition-colors leading-tight">
                {item.title}
              </h3>
              <p className="text-black/60 dark:text-white/60 font-medium text-sm leading-relaxed mb-6 flex-grow">
                {item.summary}
              </p>
              <a 
                href={item.url} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center gap-2 text-xs font-black text-blue-600 uppercase tracking-widest hover:gap-3 transition-all no-print"
              >
                Read Source <i className="fa-solid fa-arrow-right"></i>
              </a>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NewsView;
