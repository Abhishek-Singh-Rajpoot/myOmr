import React from 'react';

const AboutView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-fadeIn pb-12">
      <div className="text-center space-y-4">
        <div className="w-24 h-24 bg-blue-600 rounded-[2rem] flex items-center justify-center text-white mx-auto shadow-2xl shadow-blue-200 rotate-6">
          <i className="fa-solid fa-square-check text-5xl"></i>
        </div>
        <h1 className="text-5xl font-black text-black tracking-tighter">
          Omni<span className="text-blue-600">OMR</span>
        </h1>
        <p className="text-xl font-medium text-black/60 max-w-lg mx-auto leading-relaxed">
          The next generation of competitive exam preparation.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100 space-y-4 hover:scale-[1.02] transition-transform">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
            <i className="fa-solid fa-bolt text-xl"></i>
          </div>
          <h3 className="text-2xl font-black text-black">Our Mission</h3>
          <p className="text-black/60 font-medium leading-relaxed">
            OmniOMR was built to bridge the gap between traditional paper-based testing and modern digital convenience. We empower students to practice smarter, track their performance accurately, and clear competitive exams with confidence.
          </p>
        </div>

        <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100 space-y-4 hover:scale-[1.02] transition-transform">
          <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center">
            <i className="fa-solid fa-microchip text-xl"></i>
          </div>
          <h3 className="text-2xl font-black text-black">AI Powered</h3>
          <p className="text-black/60 font-medium leading-relaxed">
            Leveraging cutting-edge Gemini AI, we provide instant OCR for answer keys and a dedicated AI Tutor that speaks your language (Hindi/English) to help solve doubts in real-time.
          </p>
        </div>
      </div>

      <div className="bg-slate-900 rounded-[3rem] p-12 text-white overflow-hidden relative shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600 rounded-full -mr-32 -mt-32 opacity-20 blur-3xl"></div>
        <div className="relative z-10 flex flex-col items-center text-center space-y-8">
          <div className="space-y-2">
            <h2 className="text-4xl font-black tracking-tight">Meet the Developer</h2>
            <div className="w-20 h-1 bg-blue-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="space-y-6">
            <div className="w-32 h-32 rounded-full border-4 border-blue-600 p-1 mx-auto shadow-2xl">
              <img 
                src="https://ui-avatars.com/api/?name=Abhishek+Singh+Rajpoot&background=0284c7&color=fff&size=256" 
                alt="Abhishek Singh Rajpoot" 
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-3xl font-black">Abhishek Singh Rajpoot</h3>
              <p className="text-blue-400 font-black uppercase tracking-widest text-sm">Full Stack Engineer & UI Enthusiast</p>
            </div>

            <p className="max-w-xl mx-auto text-white/60 font-medium text-lg leading-relaxed">
              "Developing OmniOMR was a journey to create a tool that actually helps students save time. Every feature, from the AI-OCR to the digital bubbles, is designed for the best user experience."
            </p>

            <div className="flex justify-center gap-6 pt-4">
              <a 
                href="http://linkedin.com/in/abhishek-singh-rajpoot-931a83254/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-[#0077b5] transition-all"
                title="LinkedIn Profile"
              >
                <i className="fa-brands fa-linkedin-in text-xl"></i>
              </a>
              <a 
                href="https://github.com/Abhishek-Singh-Rajpoot" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-all"
                title="GitHub Profile"
              >
                <i className="fa-brands fa-github text-xl"></i>
              </a>
              <a 
                href="#" 
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-[#1da1f2] transition-all"
                title="Twitter Profile"
              >
                <i className="fa-brands fa-twitter text-xl"></i>
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-12 rounded-[3rem] shadow-sm border border-slate-100 text-center space-y-6">
        <h3 className="text-2xl font-black text-black">Key Features</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="font-black text-black text-xs uppercase tracking-widest">OCR Extraction</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="font-black text-black text-xs uppercase tracking-widest">Live Scoring</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="font-black text-black text-xs uppercase tracking-widest">PDF Export</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="font-black text-black text-xs uppercase tracking-widest">History Tracking</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutView;