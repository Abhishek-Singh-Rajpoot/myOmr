
import React, { memo } from 'react';
import { ExamConfig, UserResponses, AnswerKey } from '../types';

interface OMRSheetProps {
  config: ExamConfig;
  responses: UserResponses;
  answerKey: AnswerKey;
  onChange: (qNum: number, option: string) => void;
  disabled?: boolean;
}

// Memoized Row Component to prevent unnecessary re-renders
const OMRRow = memo(({ 
  qNum, 
  options, 
  userAns, 
  correctAns, 
  isShowResult, 
  disabled, 
  onChange 
}: {
  qNum: number,
  options: string[],
  userAns: string | undefined,
  correctAns: string | undefined,
  isShowResult: boolean | undefined,
  disabled?: boolean,
  onChange: (qNum: number, option: string) => void
}) => {
  return (
    <div 
      className={`flex items-center justify-between py-2 border-b border-slate-50 last:border-0 hover:bg-slate-50 px-2 rounded-xl transition-colors content-visibility-auto ${isShowResult ? (userAns === correctAns ? 'bg-green-50/50' : 'bg-red-50/50') : ''}`}
    >
      <div className="flex items-center gap-3">
        <span className="text-sm font-bold text-black/40 w-6">{qNum}.</span>
        <div className="flex gap-1.5">
          {options.map((option) => {
            const isSelected = userAns === option;
            const isCorrect = isShowResult && option === correctAns;
            const isWrong = isShowResult && isSelected && userAns !== correctAns;

            return (
              <button
                key={option}
                disabled={disabled}
                onClick={() => onChange(qNum, userAns === option ? '' : option)}
                className={`
                  w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-black transition-transform duration-75
                  ${isSelected ? 'shadow-md scale-110 z-10' : 'hover:border-blue-300'}
                  ${isCorrect ? 'bg-green-600 border-green-600 text-white' : 
                    isWrong ? 'bg-red-500 border-red-500 text-white' : 
                    isSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-200 text-black/30'}
                  ${disabled ? 'cursor-not-allowed opacity-80' : 'cursor-pointer'}
                `}
              >
                {option}
              </button>
            );
          })}
        </div>
      </div>
      <div className="flex items-center gap-2">
        {isShowResult && (
          <span className={`text-[10px] font-black uppercase ${userAns === correctAns ? 'text-green-600' : 'text-red-500'}`}>
            {userAns === correctAns ? '✓' : `✕ (${correctAns})`}
          </span>
        )}
        {userAns && !disabled && (
          <button 
            onClick={() => onChange(qNum, '')}
            className="w-5 h-5 flex items-center justify-center text-black/20 hover:text-red-500 transition-colors"
            title="Clear"
          >
            <i className="fa-solid fa-circle-xmark text-xs"></i>
          </button>
        )}
      </div>
    </div>
  );
});

const OMRSheet: React.FC<OMRSheetProps> = ({ config, responses, answerKey, onChange, disabled }) => {
  const questions = Array.from({ length: config.totalQuestions }, (_, i) => i + 1);
  const options = ['A', 'B', 'C', 'D', 'E'].slice(0, config.optionsPerQuestion);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-2 p-4 bg-white rounded-3xl shadow-sm border border-slate-100">
      {questions.map((qNum) => (
        <OMRRow 
          key={qNum}
          qNum={qNum}
          options={options}
          userAns={responses[qNum]}
          correctAns={answerKey[qNum]}
          isShowResult={config.instantFeedback && !!responses[qNum]}
          disabled={disabled}
          onChange={onChange}
        />
      ))}
    </div>
  );
};

export default memo(OMRSheet);
