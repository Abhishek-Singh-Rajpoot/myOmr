
import React, { memo } from 'react';
import { QuizQuestion, UserResponses, ExamConfig, AnswerKey } from '../types';

interface InteractiveQuizProps {
  questions: QuizQuestion[];
  responses: UserResponses;
  answerKey: AnswerKey;
  config: ExamConfig;
  onChange: (qNum: number, option: string) => void;
}

const QuizCard = memo(({ 
  q, 
  userAns, 
  correctAns, 
  isShowResult, 
  onChange 
}: {
  q: QuizQuestion,
  userAns: string | undefined,
  correctAns: string | undefined,
  isShowResult: boolean | undefined,
  onChange: (qNum: number, option: string) => void
}) => {
  const getOptionLabel = (index: number) => ['A', 'B', 'C', 'D', 'E'][index];

  return (
    <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-[2rem] shadow-sm border border-slate-100 dark:border-slate-800 animate-fadeIn content-visibility-auto contain-intrinsic-size-[200px]">
      <div className="flex gap-4 mb-6">
        <span className="flex-shrink-0 w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center font-black text-slate-500 dark:text-slate-400">
          {q.id}
        </span>
        <div className="pt-1 w-full">
          {/* whitespace-pre-wrap is crucial for Match Columns and formatted questions */}
          <h3 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-white leading-relaxed whitespace-pre-wrap">
            {q.text}
          </h3>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 pl-0 sm:pl-14">
        {q.options.map((optText, idx) => {
          const label = getOptionLabel(idx);
          const isSelected = userAns === label;
          const isCorrect = isShowResult && label === correctAns;
          const isWrong = isShowResult && isSelected && label !== correctAns;

          let cardClass = "border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500 hover:bg-slate-50 dark:hover:bg-slate-800/50";
          let iconClass = "text-slate-300";
          
          if (isSelected) {
             cardClass = "border-blue-600 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-500";
             iconClass = "text-blue-600 dark:text-blue-400";
          }
          
          if (isCorrect) {
            cardClass = "border-green-500 bg-green-50 dark:bg-green-900/20 dark:border-green-500";
            iconClass = "text-green-600";
          } else if (isWrong) {
             cardClass = "border-red-500 bg-red-50 dark:bg-red-900/20 dark:border-red-500";
             iconClass = "text-red-500";
          }

          return (
            <div 
              key={idx}
              onClick={() => !isShowResult && onChange(q.id, label)}
              className={`
                relative group cursor-pointer p-4 rounded-xl border-2 transition-colors duration-200 flex items-start gap-4
                ${cardClass}
              `}
            >
              <div className={`mt-0.5 flex-shrink-0 w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${isSelected || isCorrect || isWrong ? 'border-current' : 'border-slate-300'}`}>
                <div className={`w-3 h-3 rounded-md transition-all ${isSelected || isCorrect || isWrong ? 'bg-current scale-100' : 'scale-0'} ${iconClass}`}></div>
              </div>
              
              <div className="flex-grow text-sm sm:text-base font-medium text-slate-700 dark:text-slate-200 whitespace-pre-wrap">
                {optText}
              </div>

              {isShowResult && label === correctAns && (
                <i className="fa-solid fa-check-circle text-green-500 text-xl absolute right-4 top-1/2 -translate-y-1/2"></i>
              )}
              {isShowResult && isSelected && label !== correctAns && (
                <i className="fa-solid fa-circle-xmark text-red-500 text-xl absolute right-4 top-1/2 -translate-y-1/2"></i>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
});

const InteractiveQuiz: React.FC<InteractiveQuizProps> = ({ questions, responses, answerKey, config, onChange }) => {
  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-20">
      {questions.map((q) => (
        <QuizCard 
          key={q.id}
          q={q}
          userAns={responses[q.id]}
          correctAns={answerKey[q.id]}
          isShowResult={config.instantFeedback && !!responses[q.id]}
          onChange={onChange}
        />
      ))}
    </div>
  );
};

export default memo(InteractiveQuiz);
