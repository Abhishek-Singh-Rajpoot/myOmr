import React from 'react';
import { ExamResult, ExamConfig, AnswerKey, UserResponses } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface ResultsViewProps {
  result: ExamResult;
  config: ExamConfig;
  answerKey: AnswerKey;
  userResponses: UserResponses;
  onReset: () => void;
}

const ResultsView: React.FC<ResultsViewProps> = ({ result, config, answerKey, userResponses, onReset }) => {
  const chartData = [
    { name: 'Correct', value: result.correctCount, color: '#22c55e' },
    { name: 'Incorrect', value: result.incorrectCount, color: '#ef4444' },
    { name: 'Unattempted', value: result.unattemptedCount, color: '#94a3b8' },
  ];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-100 overflow-hidden relative">
        <div className="absolute top-0 right-0 p-4 no-print">
          <button 
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-black rounded-lg hover:bg-slate-200 transition-colors font-medium text-sm"
          >
            <i className="fa-solid fa-download"></i> Export PDF
          </button>
        </div>

        <div className="text-center space-y-2 mb-8">
          <h1 className="text-3xl font-extrabold text-black">Exam Scorecard</h1>
          <p className="text-black/50 font-medium">Practice Session Results Summary</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="text-center mt-[-100px] mb-[60px]">
               <div className="text-4xl font-black text-black">{result.score.toFixed(2)}</div>
               <div className="text-xs font-bold text-black/40 uppercase">Out of {result.maxScore}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <StatCard label="Accuracy" value={`${((result.correctCount / (result.correctCount + result.incorrectCount || 1)) * 100).toFixed(1)}%`} color="blue" />
            <StatCard label="Attempt Rate" value={`${(((config.totalQuestions - result.unattemptedCount) / config.totalQuestions) * 100).toFixed(1)}%`} color="purple" />
            <StatCard label="Net Score" value={result.score.toFixed(2)} color="indigo" />
            <StatCard label="Penalty" value={result.marksDeducted.toFixed(2)} color="red" />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6 mt-8 pt-8 border-t border-slate-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{result.correctCount}</div>
            <div className="text-xs font-medium text-black/50 uppercase tracking-wider">Correct</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-500">{result.incorrectCount}</div>
            <div className="text-xs font-medium text-black/50 uppercase tracking-wider">Incorrect</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-black/40">{result.unattemptedCount}</div>
            <div className="text-xs font-medium text-black/50 uppercase tracking-wider">Skipped</div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-100 font-bold text-black">Detailed Review</div>
        <div className="divide-y divide-slate-50 max-h-96 overflow-y-auto">
          {Array.from({ length: config.totalQuestions }, (_, i) => i + 1).map(qNum => {
            const isCorrect = userResponses[qNum] === answerKey[qNum];
            const isUnattempted = !userResponses[qNum];
            return (
              <div key={qNum} className="flex items-center justify-between p-4 hover:bg-slate-50">
                <div className="flex items-center gap-4">
                  <span className="font-bold text-black/30 w-8">Q{qNum}</span>
                  <div className="flex gap-2">
                    <span className="text-sm font-medium text-black">Your: <b className={isUnattempted ? 'text-black/30' : isCorrect ? 'text-green-600' : 'text-red-500'}>{userResponses[qNum] || '-'}</b></span>
                    <span className="text-sm font-medium text-black">Correct: <b className="text-green-600">{answerKey[qNum]}</b></span>
                  </div>
                </div>
                <div>
                  {isUnattempted ? (
                    <span className="text-[10px] px-2 py-1 bg-slate-100 text-black/50 rounded font-bold uppercase">Skipped</span>
                  ) : isCorrect ? (
                    <span className="text-[10px] px-2 py-1 bg-green-100 text-green-700 rounded font-bold uppercase">Correct</span>
                  ) : (
                    <span className="text-[10px] px-2 py-1 bg-red-100 text-red-700 rounded font-bold uppercase">Incorrect</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex justify-center pt-4 no-print">
        <button 
          onClick={onReset}
          className="px-8 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 transition-all hover:scale-105 active:scale-95"
        >
          Take Another Test
        </button>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, color }: { label: string, value: string | number, color: string }) => {
  const colorMap: Record<string, string> = {
    blue: 'text-blue-600 bg-blue-50',
    purple: 'text-purple-600 bg-purple-50',
    indigo: 'text-indigo-600 bg-indigo-50',
    red: 'text-red-600 bg-red-50',
  };
  return (
    <div className={`p-4 rounded-xl ${colorMap[color]} flex flex-col items-center justify-center text-center`}>
      <span className="text-[10px] font-bold uppercase tracking-widest opacity-70 mb-1">{label}</span>
      <span className="text-xl font-black">{value}</span>
    </div>
  );
};

export default ResultsView;