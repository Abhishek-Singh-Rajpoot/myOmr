
import { GoogleGenAI, Type } from "@google/genai";

export default async (req: Request) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }

  try {
    const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
    
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API_KEY_MISSING" }), { status: 401, headers });
    }

    const ai = new GoogleGenAI({ apiKey });
    const body = await req.json();
    const { action } = body;

    // Use the latest Flash model for speed and capability
    const modelName = 'gemini-3-flash-preview';

    // 1. OCR for Answer Key
    if (action === 'extractAnswerKey') {
      const prompt = `Extract question numbers and answers. Output JSON array: [{questionNumber: int, answer: string}]. Answer must be A-E. Ignore ambiguity.`;
      
      const response = await ai.models.generateContent({
        model: modelName,
        contents: {
          parts: [
            { inlineData: { data: body.image, mimeType: 'image/png' } },
            { text: prompt }
          ]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                questionNumber: { type: Type.INTEGER },
                answer: { type: Type.STRING }
              },
              required: ["questionNumber", "answer"]
            }
          }
        }
      });
      return new Response(JSON.stringify({ result: response.text }), { status: 200, headers });
    }

    // 2. OCR for Questions
    else if (action === 'extractQuestions') {
      const prompt = "Perform OCR. Extract all questions/options. Maintain layout.";
      const response = await ai.models.generateContent({
        model: modelName,
        contents: {
          parts: [
            { inlineData: { data: body.image, mimeType: 'image/png' } },
            { text: prompt }
          ]
        }
      });
      return new Response(JSON.stringify({ result: response.text }), { status: 200, headers });
    }

    // 3. Quiz Generation - ROBUST AI MODE
    else if (action === 'generateQuiz') {
      const systemInstruction = `
        You are an expert exam parser and quiz creator.
        Goal: Output a JSON object with a 'questions' array containing exactly ${body.numQuestions} items.

        INPUT HANDLING:
        1. **Standard MCQs**: Extract text and options directly.
        2. **Match the Following / Columns**: 
           - Format the lists clearly in the 'text' field using newlines (\\n). 
           - Example Text: "Match List-I with List-II:\\n\\nList-I\\n1. A\\n2. B\\n\\nList-II\\ni. X\\nii. Y"
           - Options should be the combination codes (e.g., "A-i, B-ii").
        3. **Assertion-Reason (A-R)**:
           - Put both Assertion (A) and Reason (R) statements in the 'text' field.
           - Options should be: "Both A and R are true...", "A is true but R is false...", etc.
        4. **True/False**: 
           - Convert to MCQ format. 
           - Options: ["True", "False"].
        5. **Fill in the Blanks**:
           - Include the blank (_______) in the text.
           - Options are the possible words to fill.

        CRITICAL RULES:
        - **Language**: Preserve original language (English, Hindi, Hinglish).
        - **Options**: Must be an array of strings. If missing, generate 4 plausible options.
        - **Correct Answer**: 
             - MUST be a single letter: "A", "B", "C", "D", or "E".
             - Normalize answers: '1' -> 'A', '2' -> 'B', 'a)' -> 'A', '(i)' -> 'A', 'क' -> 'A'.
             - If NO answer is found in text, YOU MUST SOLVE IT and provide the correct letter.

        OUTPUT SCHEMA:
        {
          "questions": [
            {
              "id": 1, 
              "text": "Question content...", 
              "options": ["Option A", "Option B", "Option C", "Option D"], 
              "correctAnswer": "A"
            }
          ]
        }
      `;

      // Limit input to safe size (1M chars is plenty for a batch)
      const safeText = body.text ? body.text.substring(0, 1000000) : "";

      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
          { role: 'user', parts: [{ text: `Process this text and output ${body.numQuestions} MCQs:\n\n${safeText}` }] }
        ],
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.INTEGER },
                    text: { type: Type.STRING },
                    options: { type: Type.ARRAY, items: { type: Type.STRING } },
                    correctAnswer: { type: Type.STRING }
                  },
                  required: ["id", "text", "options", "correctAnswer"]
                }
              }
            }
          }
        }
      });
      return new Response(JSON.stringify({ result: response.text }), { status: 200, headers });
    }

    // 4. Chat Assistant
    else if (action === 'chat') {
      const { messages, context } = body;
      const contents = messages.map((m: any) => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const response = await ai.models.generateContent({
        model: modelName,
        contents: contents,
        config: {
          systemInstruction: `You are OmniAI, an exam tutor. Respond in English/Hindi. Context: ${context}`,
        }
      });
      return new Response(JSON.stringify({ result: response.text }), { status: 200, headers });
    }

    // 5. News Logic
    else if (action === 'news') {
      const { prompt } = body;
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview', 
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                summary: { type: Type.STRING },
                url: { type: Type.STRING },
                date: { type: Type.STRING },
                source: { type: Type.STRING }
              },
              required: ["title", "summary", "url", "date"]
            }
          }
        }
      });
      return new Response(JSON.stringify({ result: response.text }), { status: 200, headers });
    } 
    
    // 6. News Translation
    else if (action === 'translate_news') {
       const response = await ai.models.generateContent({
        model: modelName,
        contents: body.prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                summary: { type: Type.STRING },
                url: { type: Type.STRING },
                date: { type: Type.STRING },
                source: { type: Type.STRING }
              },
              required: ["title", "summary", "url", "date"]
            }
          }
        }
      });
      return new Response(JSON.stringify({ result: response.text }), { status: 200, headers });
    }

    else {
      throw new Error("Invalid action type");
    }

  } catch (err: any) {
    console.error("Function Error:", err);
    return new Response(JSON.stringify({ error: err.message || "Unknown Error" }), {
      status: 500,
      headers
    });
  }
};
