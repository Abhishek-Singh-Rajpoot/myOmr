
import { AnswerKey, QuizQuestion, ChatMessage } from "../types";

// Helper to call Netlify Function
async function callGeminiFunction(payload: any) {
  try {
    const response = await fetch("/.netlify/functions/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      if (response.status === 504) {
        throw new Error("Server timed out. The text might be too long to process in one go.");
      }
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `Backend request failed with status ${response.status}`);
    }

    const data = await response.json();
    if (!data.result) {
      throw new Error("Empty result from AI service");
    }
    return data.result;
  } catch (error: any) {
    console.error("Gemini Service Error:", error);
    throw error;
  }
}

// Helper to safely parse JSON
const safeJsonParse = (str: string) => {
  try {
    return JSON.parse(str);
  } catch (e) {
    let cleanStr = str.replace(/```json\s*|\s*```/gi, "").trim();
    try {
      return JSON.parse(cleanStr);
    } catch (e2) {
      const jsonStart = cleanStr.search(/[{\[]/);
      const lastCloseBrace = cleanStr.lastIndexOf('}');
      const lastCloseBracket = cleanStr.lastIndexOf(']');
      const jsonEnd = Math.max(lastCloseBrace, lastCloseBracket);
      
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
        const extracted = cleanStr.substring(jsonStart, jsonEnd + 1);
        try {
           return JSON.parse(extracted);
        } catch (e3) {
           // console.error("Deep JSON extraction failed");
        }
      }
      console.error("JSON Parse Error on string:", str);
      throw new Error("Failed to parse AI response. The model might be overloaded or returned invalid format.");
    }
  }
};

const normalizeAnswer = (ans: string): string => {
  if (!ans) return '';
  // Remove Markdown bold/italic markers, parentheses, dots
  let cleaned = ans.trim().replace(/[\*\_\(\)\.]/g, '').toUpperCase(); 
  
  // Handle "Option A"
  if (cleaned.startsWith('OPTION')) {
    cleaned = cleaned.replace('OPTION', '').trim();
  }
  
  // Handle "Ans: A"
  if (cleaned.startsWith('ANS')) {
    cleaned = cleaned.replace('ANS', '').replace(':', '').trim();
  }

  // Handle numeric 1, 2, 3, 4
  const numericMap: {[key: string]: string} = {'1': 'A', '2': 'B', '3': 'C', '4': 'D', '5': 'E'};
  if (numericMap[cleaned]) return numericMap[cleaned];
  
  // Handle Hindi क, ख, ग, घ
  const hindiMap: {[key: string]: string} = {'क': 'A', 'ख': 'B', 'ग': 'C', 'घ': 'D', 'ड़': 'E'};
  if (hindiMap[cleaned]) return hindiMap[cleaned];

  // If it's a full word "True"/"False", keep the logic handled by the component or mapping
  // Usually we expect A/B/C/D. If 'TRUE' comes, check if it maps to index 0 or 1.
  // But here we return just the cleaned char if it looks like a single letter
  if (cleaned.length === 1 && /[A-E]/.test(cleaned)) return cleaned;

  // Fallback: take the first character if it matches
  const firstChar = cleaned.charAt(0);
  if (/[A-E]/.test(firstChar)) return firstChar;

  return cleaned; // Return original if unknown format (likely won't match answer key but preserves data)
};

export const extractAnswerKey = async (base64Image: string): Promise<AnswerKey> => {
  try {
    const jsonStr = await callGeminiFunction({
      action: 'extractAnswerKey',
      image: base64Image
    });

    const rawData = safeJsonParse(jsonStr);
    const key: AnswerKey = {};
    if (Array.isArray(rawData)) {
      rawData.forEach((item: any) => {
        const num = parseInt(item.questionNumber);
        const ans = item.answer;
        if (!isNaN(num) && typeof ans === 'string') {
          key[num] = normalizeAnswer(ans);
        }
      });
    }
    return key;
  } catch (error: any) {
    throw new Error("Failed to extract answer key. " + error.message);
  }
};

export const extractQuestions = async (base64Image: string): Promise<string> => {
  try {
    return await callGeminiFunction({
      action: 'extractQuestions',
      image: base64Image
    });
  } catch (error: any) {
    throw new Error("Failed to extract questions. " + error.message);
  }
};

/**
 * intelligently splits text into chunks to avoid timeouts
 */
const splitTextIntoChunks = (text: string, chunks: number): string[] => {
  if (chunks <= 1) return [text];
  
  const totalLength = text.length;
  const idealChunkSize = Math.ceil(totalLength / chunks);
  const result: string[] = [];
  
  let currentIndex = 0;
  for (let i = 0; i < chunks; i++) {
    let nextIndex = currentIndex + idealChunkSize;
    
    // If not the last chunk, find the nearest newline to split cleanly
    if (i < chunks - 1 && nextIndex < totalLength) {
      const lookAhead = text.indexOf('\n', nextIndex);
      const lookBack = text.lastIndexOf('\n', nextIndex);
      
      // Choose the newline closest to the ideal split point
      if (lookAhead === -1) {
        nextIndex = lookBack !== -1 ? lookBack : nextIndex;
      } else if (lookBack === -1) {
        nextIndex = lookAhead;
      } else {
        nextIndex = (Math.abs(lookAhead - nextIndex) < Math.abs(lookBack - nextIndex)) ? lookAhead : lookBack;
      }
    } else {
      nextIndex = totalLength;
    }
    
    // trim to avoid empty chunks
    const chunk = text.substring(currentIndex, nextIndex).trim();
    if (chunk) result.push(chunk);
    
    currentIndex = nextIndex + 1; // skip the newline
    if (currentIndex >= totalLength) break;
  }
  
  return result;
};

export const generateQuizFromContent = async (text: string, numQuestions: number): Promise<{ quizData: QuizQuestion[]; key: AnswerKey }> => {
  // BATCHING LOGIC:
  // Netlify functions timeout ~10s. Generating >30 questions in one go risks timeout.
  // We split the request into parallel batches of ~25 questions.
  const BATCH_SIZE = 25;
  
  try {
    let allQuestions: QuizQuestion[] = [];
    
    if (numQuestions <= BATCH_SIZE) {
      // Single Batch
      const jsonStr = await callGeminiFunction({
        action: 'generateQuiz',
        text,
        numQuestions
      });
      const data = safeJsonParse(jsonStr);
      allQuestions = Array.isArray(data) ? data : (data.questions || []);
    } else {
      // Multiple Batches
      const batchCount = Math.ceil(numQuestions / BATCH_SIZE);
      const textChunks = splitTextIntoChunks(text, batchCount);
      
      // Process in parallel
      const promises = textChunks.map((chunk, index) => {
        // Calculate how many questions we need from this chunk
        const questionsForThisChunk = Math.ceil(numQuestions / textChunks.length); 
        
        return callGeminiFunction({
          action: 'generateQuiz',
          text: chunk,
          numQuestions: questionsForThisChunk
        }).then(jsonStr => {
           const data = safeJsonParse(jsonStr);
           return Array.isArray(data) ? data : (data.questions || []);
        }).catch(err => {
           console.warn(`Batch ${index} failed:`, err);
           return []; // Continue with other batches
        });
      });
      
      const results = await Promise.all(promises);
      allQuestions = results.flat();
    }

    if (allQuestions.length === 0) {
      throw new Error("No questions were generated. The text might be unclear or the AI service is busy.");
    }

    // Post-processing: Re-index IDs and limit to requested number
    const finalQuestions = allQuestions.slice(0, numQuestions);
    const key: AnswerKey = {};
    
    finalQuestions.forEach((q, idx) => {
      const newId = idx + 1;
      q.id = newId; // Renumber sequentially
      
      // Robust Answer Normalization
      if (q.correctAnswer) {
        key[newId] = normalizeAnswer(q.correctAnswer);
      }
      
      // Ensure options are clean
      if (Array.isArray(q.options)) {
        q.options = q.options.map(opt => opt.toString().trim());
      }
    });

    return { quizData: finalQuestions, key: key };
  } catch (error: any) {
    // Improve error message for users
    if (error.message.includes("timed out")) {
       throw new Error("Processing timed out. Try splitting your text or reducing the number of questions.");
    }
    throw new Error("Quiz Generation Failed: " + error.message);
  }
};

export const sendChatMessage = async (messages: ChatMessage[], context: string): Promise<string> => {
  try {
    return await callGeminiFunction({
      action: 'chat',
      messages,
      context
    });
  } catch (error: any) {
    return "I'm sorry, I couldn't process that. Please check your connection or API key.";
  }
};

export const fetchNewsAI = async (prompt: string, isTranslation = false): Promise<any[]> => {
  try {
    const jsonStr = await callGeminiFunction({
      action: isTranslation ? 'translate_news' : 'news',
      prompt
    });
    return safeJsonParse(jsonStr);
  } catch (error) {
    throw error;
  }
};
