import React, { useState, useEffect, useRef, useCallback, Suspense, lazy } from 'react';
import { AppView, ExamConfig, AnswerKey, UserResponses, ExamResult, SavedExam, UserProfile, QuizQuestion } from './types';
import { extractAnswerKey, extractQuestions, generateQuizFromContent } from './services/geminiService';

// Lazy loading components for performance optimization
const OMRSheet = lazy(() => import('./components/OMRSheet'));
const InteractiveQuiz = lazy(() => import('./components/InteractiveQuiz'));
const ResultsView = lazy(() => import('./components/ResultsView'));
const HistoryView = lazy(() => import('./components/HistoryView'));
const AIAssistant = lazy(() => import('./components/AIAssistant'));
const AuthScreen = lazy(() => import('./components/AuthScreen'));
const AboutView = lazy(() => import('./components/AboutView'));
const NewsView = lazy(() => import('./components/NewsView'));

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.AUTH);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('omniomr_theme') === 'dark');
  const [config, setConfig] = useState<ExamConfig>({
    totalQuestions: 100,
    optionsPerQuestion: 4,
    marksPerCorrect: 1,
    negativeMarking: 0.25,
    instantFeedback: false
  });
  const [answerKey, setAnswerKey] = useState<AnswerKey>({});
  const [responses, setResponses] = useState<UserResponses>({});
  const [questionsContent, setQuestionsContent] = useState('');
  const [quizData, setQuizData] = useState<QuizQuestion[]>([]); // Store structured quiz
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Dashboard Inputs
  const [manualInput, setManualInput] = useState('');
  const [quizInputText, setQuizInputText] = useState('');
  const [quizNumQ, setQuizNumQ] = useState(10);
  const [quizMarks, setQuizMarks] = useState(1);
  const [quizNegative, setQuizNegative] = useState(0.25);

  const [examName, setExamName] = useState('');
  const [savedExams, setSavedExams] = useState<SavedExam[]>([]);
  const [currentExamId, setCurrentExamId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const questionPaperInputRef = useRef<HTMLInputElement>(null);
  const dashboardScrollRef = useRef<HTMLDivElement>(null);

  // Optimized response handler using useCallback to prevent re-renders of all OMR rows
  const handleResponseChange = useCallback((qNum: number, option: string) => {
    setResponses(prev => ({...prev, [qNum]: option}));
  }, []);

  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('omniomr_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('omniomr_theme', 'light');
    }
  }, [darkMode]);

  useEffect(() => {
    const storedUser = localStorage.getItem('omniomr_active_user');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setUser(userData);
        setView(AppView.DASHBOARD);
      } catch (e) {
        console.error("Failed to parse stored user", e);
      }
    }
  }, []);

  useEffect(() => {
    if (user) {
      const historyKey = `omniomr_history_${user.email}`;
      const storedHistory = localStorage.getItem(historyKey);
      if (storedHistory) {
        try {
          setSavedExams(JSON.parse(storedHistory));
        } catch (e) {
          console.error("Failed to parse history for user", e);
          setSavedExams([]);
        }
      } else {
        setSavedExams([]);
      }
    } else {
      setSavedExams([]);
    }
  }, [user]);

  const handleLogin = (name: string, email: string) => {
    const newUser = { name, email, photo: `https://ui-avatars.com/api/?name=${name}&background=random` };
    setUser(newUser);
    localStorage.setItem('omniomr_active_user', JSON.stringify(newUser));
    setView(AppView.DASHBOARD);
  };

  const handleLogout = () => {
    if (confirm("Are you sure you want to log out? Your data for this account is safely stored.")) {
      setUser(null);
      localStorage.removeItem('omniomr_active_user');
      setResponses({});
      setAnswerKey({});
      setQuestionsContent('');
      setQuizData([]);
      setExamName('');
      setCurrentExamId(null);
      setView(AppView.AUTH);
    }
  };

  const updateSavedExams = (newList: SavedExam[]) => {
    setSavedExams(newList);
    if (user) {
      localStorage.setItem(`omniomr_history_${user.email}`, JSON.stringify(newList));
    }
  };

  const calculateLiveResult = (): ExamResult => {
    let score = 0;
    let correctCount = 0;
    let incorrectCount = 0;
    let unattemptedCount = 0;
    let marksDeducted = 0;

    for (let i = 1; i <= config.totalQuestions; i++) {
      const correct = answerKey[i];
      const userAns = responses[i];

      if (!userAns) {
        unattemptedCount++;
      } else if (userAns === correct) {
        correctCount++;
        score += config.marksPerCorrect;
      } else {
        incorrectCount++;
        const penalty = config.negativeMarking * config.marksPerCorrect;
        score -= penalty;
        marksDeducted += penalty;
      }
    }

    return {
      score: Math.max(0, score),
      correctCount,
      incorrectCount,
      unattemptedCount,
      marksDeducted,
      maxScore: config.totalQuestions * config.marksPerCorrect,
      timestamp: Date.now()
    };
  };

  // Logic to save exam without finishing (IN_PROGRESS)
  const handleSaveProgress = () => {
     const examToSave: SavedExam = {
      id: currentExamId || Date.now().toString(),
      name: examName || `Draft - ${new Date().toLocaleDateString()}`,
      date: new Date().toISOString(),
      config,
      answerKey,
      questionsContent,
      quizData: quizData.length > 0 ? quizData : undefined,
      result: calculateLiveResult(), // Temporary result
      sourceType: quizData.length > 0 ? 'TEXT' : 'MANUAL',
      status: 'IN_PROGRESS',
      savedResponses: responses
    };

    let updatedList;
    if (currentExamId) {
      updatedList = savedExams.map(ex => ex.id === currentExamId ? examToSave : ex);
    } else {
      updatedList = [examToSave, ...savedExams];
    }
    
    updateSavedExams(updatedList);
    alert("Progress saved! You can resume this test from History later.");
    setView(AppView.DASHBOARD);
  };

  // Logic to finish exam (COMPLETED)
  const handleFinishExam = () => {
    const result = calculateLiveResult();
    const examToSave: SavedExam = {
      id: currentExamId || Date.now().toString(),
      name: examName || `Session - ${new Date().toLocaleDateString()}`,
      date: new Date().toISOString(),
      config,
      answerKey,
      questionsContent,
      quizData: quizData.length > 0 ? quizData : undefined,
      result,
      sourceType: quizData.length > 0 ? 'TEXT' : 'MANUAL',
      status: 'COMPLETED',
      savedResponses: responses
    };

    let updatedList;
    if (currentExamId) {
      updatedList = savedExams.map(ex => ex.id === currentExamId ? examToSave : ex);
    } else {
      updatedList = [examToSave, ...savedExams];
    }
    
    updateSavedExams(updatedList);
    setView(AppView.RESULTS);
  };

  const loadExamFromHistory = (exam: SavedExam) => {
    setCurrentExamId(exam.id);
    setConfig(exam.config);
    setAnswerKey(exam.answerKey);
    setExamName(exam.name);
    setQuestionsContent(exam.questionsContent || '');
    setQuizData(exam.quizData || []);
    
    // Resume logic
    if (exam.status === 'IN_PROGRESS' && exam.savedResponses) {
      setResponses(exam.savedResponses);
      setView(AppView.SOLVING);
    } else {
      // Review logic (reset responses if you want a fresh start, or show old ones if review)
      // For "Retake", we usually clear responses.
      setResponses({});
      if (exam.quizData && exam.quizData.length > 0) {
        setView(AppView.SOLVING);
      } else {
        setView(AppView.SETUP);
      }
    }
  };

  const handleEditExam = (exam: SavedExam) => {
    setCurrentExamId(exam.id);
    setConfig(exam.config);
    setAnswerKey(exam.answerKey);
    setExamName(exam.name);
    setQuestionsContent(exam.questionsContent || '');
    setQuizData(exam.quizData || []);
    setResponses(exam.savedResponses || {}); 
    setView(AppView.SETUP);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    setError(null);
    setQuizData([]); // Clear previous quiz data
    setResponses({}); // Clear previous responses
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      try {
        const extracted = await extractAnswerKey(base64);
        setAnswerKey(extracted);
        const maxQ = Math.max(0, ...Object.keys(extracted).map(Number));
        if (maxQ > 0) {
          setConfig(prev => ({ ...prev, totalQuestions: Math.max(prev.totalQuestions, maxQ) }));
        }
        setView(AppView.SETUP);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleQuestionUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      try {
        const text = await extractQuestions(base64);
        setQuestionsContent(prev => prev ? prev + '\n\n' + text : text);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const parseManualKey = () => {
    try {
      setQuizData([]); // Clear previous quiz data
      const newKey: AnswerKey = {};
      const regex = /(\d+)[.\s\-:]+[\s\*\(]*([a-eA-E])[\s\*\)]*/g;
      let match;
      let count = 0;
      while ((match = regex.exec(manualInput)) !== null) {
        const qNum = parseInt(match[1]);
        const answer = match[2].toUpperCase();
        newKey[qNum] = answer;
        count++;
      }
      if (count === 0) throw new Error("Format not recognized. Use '1. A' or '1-A'.");
      setAnswerKey(newKey);
      setResponses({}); // Clear responses so OMR sheet is blank
      setQuestionsContent('');
      setCurrentExamId(null);
      const maxQ = Math.max(...Object.keys(newKey).map(Number));
      setConfig(prev => ({ ...prev, totalQuestions: Math.max(prev.totalQuestions, maxQ) }));
      setView(AppView.SETUP);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleQuizGeneration = async () => {
    if (!quizInputText.trim()) {
      setError("Please enter some text or questions.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      // Updated to use the new service that returns structured data
      const { quizData: generatedQuiz, key } = await generateQuizFromContent(quizInputText, quizNumQ);
      setQuizData(generatedQuiz);
      setAnswerKey(key);
      setConfig(prev => ({
        ...prev,
        totalQuestions: Object.keys(key).length,
        marksPerCorrect: quizMarks,
        negativeMarking: quizNegative
      }));
      setExamName("AI Generated Mock Test");
      setCurrentExamId(null);
      setResponses({});
      setQuestionsContent(''); // Clear legacy text content as we have structured data
      setView(AppView.SOLVING);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSetApiKey = () => {
    const key = prompt("Enter your Gemini API Key:", localStorage.getItem('omniomr_api_key') || '');
    if (key) {
      localStorage.setItem('omniomr_api_key', key);
      setError(null);
      alert("API Key saved! You can now use AI features.");
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    el?.scrollIntoView({ behavior: 'smooth' });
    setError(null);
  };

  // Loading Fallback Component
  const PageLoader = () => (
    <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
      <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
      <p className="text-black/40 dark:text-white/40 font-black text-xs uppercase tracking-widest animate-pulse">Loading...</p>
    </div>
  );

  const liveResult = calculateLiveResult();

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-white' : 'bg-[#f8fafc] text-black'}`}>
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView(AppView.DASHBOARD)}>
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-100">
              <i className="fa-solid fa-square-check text-xl"></i>
            </div>
            <span className="text-xl font-black tracking-tight hidden sm:block">Omni<span className="text-blue-600">OMR</span></span>
          </div>

          <nav className="flex items-center gap-1 sm:gap-2">
            <NavBtn icon="fa-house" active={view === AppView.DASHBOARD} onClick={() => setView(AppView.DASHBOARD)}>Dashboard</NavBtn>
            <NavBtn icon="fa-archive" active={view === AppView.HISTORY} onClick={() => setView(AppView.HISTORY)}>History</NavBtn>
            <NavBtn icon="fa-newspaper" color="orange" active={view === AppView.NEWS} onClick={() => setView(AppView.NEWS)}>Current Affairs</NavBtn>
            <NavBtn icon="fa-wand-magic-sparkles" color="purple" active={view === AppView.AI_ASSISTANT} onClick={() => setView(AppView.AI_ASSISTANT)}>AI Tutor</NavBtn>
          </nav>

          <div className="flex items-center gap-2 sm:gap-4">
            <button 
              onClick={handleSetApiKey}
              className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-yellow-400 hover:text-blue-600 hover:scale-110 transition-all border border-transparent dark:border-slate-700"
              title="Set API Key"
            >
              <i className="fa-solid fa-key"></i>
            </button>
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-yellow-400 hover:scale-110 transition-all border border-transparent dark:border-slate-700"
              title="Toggle Dark Mode"
            >
              <i className={`fa-solid ${darkMode ? 'fa-sun' : 'fa-moon'}`}></i>
            </button>
            <div className="hidden md:block text-right">
              <p className="text-[10px] font-black text-black/30 dark:text-white/30 uppercase tracking-widest leading-none mb-1">Signed in as</p>
              <p className="text-sm font-bold leading-none">{user?.name}</p>
            </div>
            <button onClick={handleLogout} className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 overflow-hidden hover:border-red-400 transition-all shadow-sm">
              <img src={user?.photo} alt="Profile" className="w-full h-full object-cover" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl" ref={dashboardScrollRef}>
        <Suspense fallback={<PageLoader />}>
        {view === AppView.AUTH && <AuthScreen onLogin={handleLogin} />}

        {view === AppView.DASHBOARD && (
          <div className="max-w-5xl mx-auto space-y-12 animate-fadeIn">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] shadow-xl border border-slate-100 dark:border-slate-800 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 dark:bg-blue-900/10 rounded-full -mr-32 -mt-32 opacity-50"></div>
               <div className="relative z-10 space-y-2">
                 <h1 className="text-5xl font-black">Welcome, {user?.name.split(' ')[0]}!</h1>
                 <p className="text-black/50 dark:text-white/50 font-medium text-lg">Your account: {user?.email}</p>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12 relative z-10">
                 <DashboardStat label="Papers Solved" value={savedExams.length} icon="fa-file-lines" color="blue" />
                 <DashboardStat label="Avg Score" value={savedExams.length ? `${(savedExams.reduce((acc, ex) => acc + (ex.result?.score || 0), 0) / savedExams.length).toFixed(1)}` : '0'} icon="fa-chart-line" color="green" />
                 <DashboardStat label="Total Marks" value={savedExams.reduce((acc, ex) => acc + (ex.result?.score || 0), 0).toFixed(0)} icon="fa-trophy" color="orange" />
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <ActionButton 
                title="Scan Answer Key" 
                desc="Extract answers from a photo using AI OCR technology." 
                icon="fa-camera" 
                onClick={() => fileInputRef.current?.click()} 
                loading={isLoading}
              />
              <ActionButton 
                title="Manual Key Input" 
                desc="Paste or type answer keys in text format." 
                icon="fa-keyboard" 
                color="purple"
                onClick={() => scrollToSection('manual-entry-section')}
              />
              <ActionButton 
                title="Text to Test" 
                desc="Generate a mock test from text or questions." 
                icon="fa-wand-magic-sparkles" 
                color="pink"
                onClick={() => scrollToSection('quiz-gen-section')}
              />
            </div>

            {/* AI Quiz Generator Section */}
            <div id="quiz-gen-section" className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-800 scroll-mt-24">
               <h3 className="text-2xl font-black mb-2 flex items-center gap-3">
                 <i className="fa-solid fa-wand-magic-sparkles text-pink-600"></i> AI Quiz Generator
               </h3>
               <p className="text-black/50 dark:text-white/50 font-medium mb-6">
                 Paste questions/notes (Hindi/English) in <b>ANY format</b> Paste questions with answers (e.g. "Q1... Ans: A") or study notes. AI will create an interactive test.
               </p>
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Question Limit</label>
                   <input 
                      type="number" 
                      min="1" 
                      max="300" 
                      value={quizNumQ} 
                      onChange={e => {
                         const val = parseInt(e.target.value);
                         // STRICTLY ENFORCE MAX 300
                         if (val > 300) setQuizNumQ(300);
                         else if (val < 1) setQuizNumQ(1);
                         else setQuizNumQ(val);
                      }} 
                      className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-black focus:ring-2 focus:ring-pink-500 outline-none" 
                      placeholder="Max 300" 
                   />
                 </div>
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Marks/Q</label>
                   <input type="number" value={quizMarks} onChange={e => setQuizMarks(parseFloat(e.target.value))} className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-black focus:ring-2 focus:ring-pink-500 outline-none" />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Negative Marking</label>
                    <select value={quizNegative} onChange={e => setQuizNegative(parseFloat(e.target.value))} className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-black focus:ring-2 focus:ring-pink-500 outline-none">
                      <option value={0}>None</option>
                      <option value={0.25}>0.25</option>
                      <option value={0.33}>0.33</option>
                      <option value={0.5}>0.5</option>
                    </select>
                 </div>
               </div>
               
               <textarea
                  className="w-full p-6 bg-slate-50 dark:bg-slate-950 border-0 rounded-2xl text-base font-medium mb-6 min-h-[250px] focus:ring-2 focus:ring-pink-500 transition-all outline-none"
                  placeholder="Paste UNLIMITED text/lines here (Infinite scroll).
The AI will generate up to 300 questions from your content.
Supported formats: PDF text copy, scanned notes, website content, mixed Hindi/English.
Example:
Q1. ... ? (A) ... (B) ... 
..."
                  value={quizInputText}
                  onChange={(e) => setQuizInputText(e.target.value)}
                />
               <button 
                  onClick={handleQuizGeneration} 
                  disabled={isLoading}
                  className="w-full py-5 bg-slate-900 dark:bg-pink-600 text-white rounded-2xl font-black text-lg hover:bg-pink-600 dark:hover:bg-pink-700 transition-all shadow-xl shadow-slate-200 dark:shadow-none disabled:opacity-50"
               >
                  {isLoading ? <i className="fa-solid fa-circle-notch fa-spin mr-2"></i> : <i className="fa-solid fa-bolt mr-2"></i>} Generate / Parse Test
               </button>
            </div>

            {/* Manual Key Entry Section */}
            <div id="manual-entry-section" className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-800 scroll-mt-24">
               <h3 className="text-2xl font-black mb-6 flex items-center gap-3">
                 <i className="fa-solid fa-keyboard text-purple-600"></i> Manual Key Entry
               </h3>
               <textarea
                  className="w-full p-6 bg-slate-50 dark:bg-slate-950 border-0 rounded-2xl text-lg font-medium mb-6 min-h-[150px] focus:ring-2 focus:ring-purple-500 transition-all outline-none"
                  placeholder="Paste keys here: 1-A, 2-B, 3-C..."
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                />
               <button onClick={parseManualKey} className="w-full py-5 bg-slate-900 dark:bg-purple-600 text-white rounded-2xl font-black text-lg hover:bg-purple-600 dark:hover:bg-purple-700 transition-all shadow-xl shadow-slate-200 dark:shadow-none">
                  <i className="fa-solid fa-check mr-2"></i> Create OMR Sheet
               </button>
            </div>
            
            <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
          </div>
        )}

        {view === AppView.SETUP && (
          <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-slate-800">
              <h2 className="text-4xl font-black mb-8 tracking-tight">Setup Exam</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                <div className="space-y-8">
                  <div className="grid grid-cols-2 gap-6">
                    <InputGroup label="Questions" value={config.totalQuestions} onChange={v => setConfig(p => ({ ...p, totalQuestions: v }))} />
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Marks/Q</label>
                      <input type="number" step="0.5" value={config.marksPerCorrect} onChange={e => setConfig(p => ({ ...p, marksPerCorrect: parseFloat(e.target.value) }))} className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-black text-lg focus:ring-2 focus:ring-blue-500 outline-none" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Negative Marking</label>
                      <select value={config.negativeMarking} onChange={e => setConfig(p => ({ ...p, negativeMarking: parseFloat(e.target.value) }))} className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-black text-lg focus:ring-2 focus:ring-blue-500 outline-none">
                        <option value={0}>None</option>
                        <option value={0.25}>1/4th (0.25)</option>
                        <option value={0.33}>1/3rd (0.33)</option>
                        <option value={0.5}>1/2 (0.5)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Feedback Mode</label>
                       <button 
                        onClick={() => setConfig(p => ({ ...p, instantFeedback: !p.instantFeedback }))}
                        className={`w-full p-4 rounded-2xl font-black text-sm transition-all border-2 ${config.instantFeedback ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 text-black/30 dark:text-white/30'}`}
                       >
                         {config.instantFeedback ? 'INSTANT ON' : 'SUBMIT MODE'}
                       </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Exam Name</label>
                    <input type="text" placeholder="e.g. UPSC Prelims 2024" className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-bold focus:ring-2 focus:ring-blue-500 outline-none" value={examName} onChange={e => setExamName(e.target.value)} />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">Question Paper (Optional)</label>
                    <button 
                      onClick={() => questionPaperInputRef.current?.click()}
                      disabled={isLoading}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/50 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all disabled:opacity-50 shadow-sm"
                    >
                      {isLoading ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-camera"></i>}
                      Scan Paper (OCR)
                    </button>
                    <input type="file" ref={questionPaperInputRef} onChange={handleQuestionUpload} className="hidden" accept="image/*" />
                  </div>
                  <textarea
                    className="w-full p-6 bg-slate-50 dark:bg-slate-950 border-0 rounded-2xl text-base font-medium min-h-[250px] focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                    placeholder="Paste your questions here or click 'Scan Paper' to extract from a photo..."
                    value={questionsContent}
                    onChange={(e) => setQuestionsContent(e.target.value)}
                  />
                  {isLoading && (
                    <div className="text-[10px] font-bold text-blue-600 dark:text-blue-400 flex items-center gap-2 animate-pulse">
                      <i className="fa-solid fa-gear fa-spin"></i> AI is extracting questions from your image...
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-4 pt-8">
                <button onClick={() => setView(AppView.DASHBOARD)} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-black/50 dark:text-white/50 rounded-2xl font-black text-xs uppercase tracking-widest">Back</button>
                <button onClick={() => setView(AppView.SOLVING)} className="flex-[2] py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 dark:shadow-none">Start Attempt</button>
              </div>
            </div>
          </div>
        )}

        {view === AppView.SOLVING && (
          <div className="max-w-[1600px] mx-auto space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] shadow-sm border border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4 sticky top-20 z-40">
              <div className="flex items-center gap-6">
                <div>
                  <h2 className="text-xl font-black">{examName || 'Untitled Practice'}</h2>
                  <p className="text-xs font-bold text-black/40 dark:text-white/40 uppercase">Q: {Object.keys(responses).length} / {config.totalQuestions} Attempted</p>
                </div>
                <div className="h-10 w-px bg-slate-100 dark:bg-slate-800 hidden sm:block"></div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <p className="text-[9px] font-black text-black/40 dark:text-white/40 uppercase">Live Score</p>
                    <p className="text-lg font-black text-blue-600">{liveResult.score.toFixed(2)}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] font-black text-black/40 dark:text-white/40 uppercase">Accuracy</p>
                    <p className="text-lg font-black">{((liveResult.correctCount / (Object.keys(responses).length || 1)) * 100).toFixed(0)}%</p>
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={handleSaveProgress} className="bg-slate-100 dark:bg-slate-800 text-black dark:text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700 transition-all">
                   Save Progress
                </button>
                <button onClick={handleFinishExam} className="bg-green-600 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-green-700 transition-all shadow-lg shadow-green-100 dark:shadow-none">
                   Finish & Save
                </button>
              </div>
            </div>

            {quizData.length > 0 ? (
               // New Interactive View for AI generated quizzes
               <InteractiveQuiz 
                  questions={quizData} 
                  responses={responses} 
                  answerKey={answerKey} 
                  config={config} 
                  onChange={handleResponseChange} 
               />
            ) : (
               // Old View for Manual/Image upload
               <div className={`grid gap-6 ${questionsContent ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
                  {questionsContent && (
                    <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm p-8 max-h-[75vh] overflow-y-auto">
                       <h3 className="text-lg font-black mb-6 uppercase tracking-widest flex items-center gap-2">
                         <i className="fa-solid fa-file-lines text-blue-600"></i> Question Paper
                       </h3>
                       <div className="prose dark:prose-invert prose-slate max-w-none leading-relaxed whitespace-pre-wrap font-medium">
                         {questionsContent}
                       </div>
                    </div>
                  )}
                  <div className={questionsContent ? 'max-h-[75vh] overflow-y-auto' : ''}>
                    <OMRSheet config={config} responses={responses} answerKey={answerKey} onChange={handleResponseChange} />
                  </div>
                </div>
            )}
          </div>
        )}

        {view === AppView.RESULTS && (
          <ResultsView 
            result={liveResult} 
            config={config} 
            answerKey={answerKey} 
            userResponses={responses} 
            onReset={() => {
              setCurrentExamId(null);
              setResponses({});
              setQuizData([]);
              setQuestionsContent('');
              setView(AppView.DASHBOARD);
            }} 
          />
        )}

        {view === AppView.HISTORY && (
          <HistoryView 
            exams={savedExams} 
            onLoad={loadExamFromHistory} 
            onEdit={handleEditExam}
            onDelete={(id) => updateSavedExams(savedExams.filter(e => e.id !== id))} 
            onAddClick={() => setView(AppView.DASHBOARD)}
          />
        )}

        {view === AppView.AI_ASSISTANT && <AIAssistant userEmail={user?.email} currentConfig={config} currentResult={liveResult} />}
        
        {view === AppView.ABOUT && <AboutView />}

        {view === AppView.NEWS && <NewsView />}
        </Suspense>
      </main>

      {error === 'API_KEY_MISSING' ? (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-red-600 text-white px-8 py-4 rounded-full font-bold shadow-2xl z-50 flex items-center gap-4 animate-bounce">
          <span>⚠️ API Key not found.</span>
          <button 
            onClick={handleSetApiKey}
            className="bg-white text-red-600 px-4 py-2 rounded-xl text-xs uppercase hover:bg-red-50 font-black"
          >
            Set Key
          </button>
        </div>
      ) : error && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-red-600 text-white px-8 py-4 rounded-full font-bold shadow-2xl animate-bounce z-50">{error}</div>
      )}

      <footer className="py-8 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 mt-auto no-print">
        <div className="container mx-auto px-4 text-center">
          <p className="text-black/30 dark:text-white/30 text-[10px] font-black uppercase tracking-[0.3em]">&copy; {new Date().getFullYear()} OmniOMR • Your Personal Study Lab</p>
        </div>
      </footer>
    </div>
  );
};

const DashboardStat = ({ label, value, icon, color }: any) => (
  <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-50 dark:border-slate-800 shadow-sm flex flex-col items-center text-center">
    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 bg-${color}-50 dark:bg-${color}-900/20 text-${color}-600 dark:text-${color}-400`}>
      <i className={`fa-solid ${icon} text-lg`}></i>
    </div>
    <span className="text-[10px] font-black text-black/30 dark:text-white/30 uppercase tracking-widest mb-1">{label}</span>
    <span className="text-2xl font-black">{value}</span>
  </div>
);

const ActionButton = ({ title, desc, icon, onClick, loading, color = "blue" }: any) => (
  <button 
    onClick={onClick} 
    className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-lg border border-slate-100 dark:border-slate-800 hover:scale-[1.02] active:scale-95 transition-all text-left group"
  >
    <div className={`w-14 h-14 bg-${color}-50 dark:bg-${color}-900/20 text-${color}-600 dark:text-${color}-400 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-${color}-600 dark:group-hover:bg-${color}-500 group-hover:text-white transition-all shadow-sm`}>
      {loading ? <i className="fa-solid fa-circle-notch fa-spin text-xl"></i> : <i className={`fa-solid ${icon} text-xl`}></i>}
    </div>
    <h3 className="text-xl font-black mb-2">{title}</h3>
    <p className="text-black/50 dark:text-white/50 text-sm font-medium leading-relaxed">{desc}</p>
  </button>
);

const NavBtn = ({ children, icon, active, onClick, color = "blue" }: any) => (
  <button 
    onClick={onClick} 
    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${active ? `bg-${color}-50 dark:bg-${color}-900/20 text-${color}-600 dark:text-${color}-400` : 'text-black/40 dark:text-white/40 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
  >
    <i className={`fa-solid ${icon}`}></i>
    <span className="hidden lg:inline">{children}</span>
  </button>
);

const InputGroup = ({ label, value, onChange }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black text-black/40 dark:text-white/40 uppercase tracking-widest">{label}</label>
    <input 
      type="number" 
      value={value} 
      onChange={e => onChange(parseInt(e.target.value) || 0)} 
      className="w-full p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl font-black text-xl focus:ring-2 focus:ring-blue-500 outline-none" 
    />
  </div>
);

export default App;